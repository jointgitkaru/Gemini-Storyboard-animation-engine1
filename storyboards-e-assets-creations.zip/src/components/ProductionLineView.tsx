import React from 'react';
import { 
  UserCheck, 
  Scale, 
  Sparkles, 
  Grid3X3, 
  Film, 
  ArrowRight, 
  ShieldCheck, 
  Lock, 
  Camera, 
  ExternalLink 
} from 'lucide-react';
import { motion } from 'motion/react';
import { TabType } from '../types';
import { PRODUCTION_PIPELINE_STEPS } from '../data/protocolsData';

interface ProductionLineViewProps {
  onNavigate: (tab: TabType) => void;
}

export const ProductionLineView: React.FC<ProductionLineViewProps> = ({ onNavigate }) => {
  const stepIcons = [UserCheck, Scale, Sparkles, Grid3X3, Film];
  const stepTargets: TabType[] = ['character-sheet', 'scale-2x2', 'styles', 'depth-3x3', 'storyboard-5x3'];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      className="space-y-8 max-w-7xl mx-auto py-2"
    >
      {/* Hero Golden Rule Banner - Dark Gray Cinematic Atmosphere */}
      <motion.div 
        whileHover={{ scale: 1.002 }}
        className="relative overflow-hidden rounded-2xl border border-amber-500/30 bg-gradient-to-r from-amber-500/10 via-[#21232d] to-[#1a1b22] p-6 md:p-8 shadow-xl shadow-black/30 transition-all"
      >
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase tracking-wider bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                Regra de Ouro da Linha de Produção (OAK)
              </span>
              <span className="text-xs text-slate-400 font-mono">5 Protocolos Travados</span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">
              A referência controla o <span className="text-amber-400">look</span>; o board de profundidade controla a <span className="text-amber-400">câmera</span>; as character sheets controlam a <span className="text-amber-400">identidade</span>.
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              Cada protocolo trava uma dimensão exata do problema sem contaminação entre etapas. Prompts são compostos por <strong className="text-amber-300">lock blocks</strong> (palavra por palavra, nunca parafraseados) + <strong className="text-amber-300">slots</strong> (valores variáveis da produção).
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <motion.button
              whileTap={{ scale: 0.96 }}
              whileHover={{ scale: 1.02 }}
              onClick={() => onNavigate('storyboard-5x3')}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs font-mono flex items-center gap-2 transition-all shadow-md shadow-amber-500/20"
            >
              <span>Abrir Engine 5×3</span>
              <ArrowRight className="w-4 h-4" />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.96 }}
              whileHover={{ scale: 1.02 }}
              onClick={() => onNavigate('scale-2x2')}
              className="px-4 py-2.5 rounded-xl bg-[#252833] hover:bg-[#2d303e] text-slate-200 text-xs font-mono font-medium border border-[#373a4b] flex items-center gap-2 transition-all shadow-xs"
            >
              <span>Calculadora Escala Lata</span>
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* 5-Step Pipeline Cards in Dark Gray with Motion */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            Sequência Obrigatória de Travamento
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Etapas 1 a 5 · Linha de Produção
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {PRODUCTION_PIPELINE_STEPS.map((step, idx) => {
            const Icon = stepIcons[idx];
            const targetTab = stepTargets[idx];
            return (
              <motion.div 
                key={step.step}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: idx * 0.08 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                className="group relative rounded-2xl border border-[#2e313f] bg-[#1f2029] p-5 hover:border-amber-500/50 hover:shadow-xl hover:shadow-black/40 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-mono font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/30">
                      ETAPA {step.step}
                    </span>
                    <div className="w-9 h-9 rounded-xl bg-[#282a36] border border-[#3a3d4e] flex items-center justify-center text-slate-300 group-hover:text-amber-400 group-hover:border-amber-500/40 transition-colors">
                      <Icon className="w-4 h-4" />
                    </div>
                  </div>

                  <h4 className="text-sm font-bold text-white mb-1 group-hover:text-amber-300 transition-colors">
                    {step.name}
                  </h4>
                  
                  <div className="inline-block px-2 py-0.5 rounded text-[11px] font-mono font-medium bg-[#181920] text-amber-300 border border-[#2d303e] mb-2.5">
                    {step.dimension}
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed mb-3">
                    {step.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-[#2a2c3a] space-y-2.5">
                  <div className="flex items-start gap-1.5 text-[11px] text-slate-400">
                    <Lock className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                    <span className="font-mono text-[10px] leading-tight text-slate-300">
                      {step.gate}
                    </span>
                  </div>

                  <button
                    onClick={() => onNavigate(targetTab)}
                    className="w-full py-2 px-3 rounded-xl bg-[#262834] hover:bg-amber-500 hover:text-slate-950 text-slate-200 text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition-all shadow-xs"
                  >
                    <span>Configurar Etapa</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Production Matrix in Dark Gray */}
      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, delay: 0.2 }}
        className="rounded-2xl border border-[#2e313f] bg-[#1f2029] p-6 space-y-4 shadow-md"
      >
        <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
          <Camera className="w-4 h-4 text-amber-400" />
          Matriz de Separação de Responsabilidades
        </h3>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#2e313f] text-slate-400 font-mono text-[11px]">
                <th className="py-3 px-3">Dimensão Visual</th>
                <th className="py-3 px-3">Protocolo Responsável</th>
                <th className="py-3 px-3">Regra Inviolável</th>
                <th className="py-3 px-3">Formato de Saída</th>
                <th className="py-3 px-3">Ação Rápida</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#282a36] font-sans">
              <tr className="hover:bg-[#252733] transition-colors">
                <td className="py-3 px-3 font-semibold text-white">Identidade do Personagem</td>
                <td className="py-3 px-3 font-mono text-amber-400">Character Reference Sheet v2.0</td>
                <td className="py-3 px-3 text-slate-300">11 seções, régua métrica, sem cena dramática, estúdio neutro</td>
                <td className="py-3 px-3 font-mono text-slate-400">Sheet horizontal com turnarounds</td>
                <td className="py-3 px-3">
                  <button onClick={() => onNavigate('character-sheet')} className="text-amber-400 hover:underline flex items-center gap-1 font-mono text-[11px] font-semibold">
                    Ver v2.0 <ExternalLink className="w-3 h-3" />
                  </button>
                </td>
              </tr>
              <tr className="hover:bg-[#252733] transition-colors">
                <td className="py-3 px-3 font-semibold text-white">Escala e Proporções Físicas</td>
                <td className="py-3 px-3 font-mono text-amber-400">Protocolo Lata Coca-Cola 2×2</td>
                <td className="py-3 px-3 text-slate-300">Lata 33cl (11,5 cm) no mesmo plano de chão a 5-10 cm de distância</td>
                <td className="py-3 px-3 font-mono text-slate-400">Grid 2×2 ortogonal</td>
                <td className="py-3 px-3">
                  <button onClick={() => onNavigate('scale-2x2')} className="text-amber-400 hover:underline flex items-center gap-1 font-mono text-[11px] font-semibold">
                    Calcular <ExternalLink className="w-3 h-3" />
                  </button>
                </td>
              </tr>
              <tr className="hover:bg-[#252733] transition-colors">
                <td className="py-3 px-3 font-semibold text-white">Estética, Iluminação e Textura</td>
                <td className="py-3 px-3 font-mono text-amber-400">Cinematic Photo-Realism (A, B, C)</td>
                <td className="py-3 px-3 text-slate-300">1 único registro por produção; colado palavra por palavra</td>
                <td className="py-3 px-3 font-mono text-slate-400">Locked text block</td>
                <td className="py-3 px-3">
                  <button onClick={() => onNavigate('styles')} className="text-amber-400 hover:underline flex items-center gap-1 font-mono text-[11px] font-semibold">
                    Escolher <ExternalLink className="w-3 h-3" />
                  </button>
                </td>
              </tr>
              <tr className="hover:bg-[#252733] transition-colors">
                <td className="py-3 px-3 font-semibold text-white">Câmera, Profundidade e Sequência</td>
                <td className="py-3 px-3 font-mono text-amber-400">Depth Board 3×3 & Sheet 5×3</td>
                <td className="py-3 px-3 text-slate-300">Linear grayscale (branco=perto, preto=longe); 9 ou 15 beats narrativos</td>
                <td className="py-3 px-3 font-mono text-slate-400">Grid 3×3 ou 5×3 com timecodes</td>
                <td className="py-3 px-3">
                  <button onClick={() => onNavigate('depth-3x3')} className="text-amber-400 hover:underline flex items-center gap-1 font-mono text-[11px] font-semibold">
                    Configurar <ExternalLink className="w-3 h-3" />
                  </button>
                </td>
              </tr>
              <tr className="hover:bg-[#252733] transition-colors">
                <td className="py-3 px-3 font-semibold text-white">Animação e Continuidade Temporal</td>
                <td className="py-3 px-3 font-mono text-amber-400">Seedance 2.0 Engine Call</td>
                <td className="py-3 px-3 text-slate-300">24 fps temporal feel, recebe o mesmo Style Register da Etapa 3</td>
                <td className="py-3 px-3 font-mono text-slate-400">Prompt de animação sincronizado</td>
                <td className="py-3 px-3">
                  <button onClick={() => onNavigate('storyboard-5x3')} className="text-amber-400 hover:underline flex items-center gap-1 font-mono text-[11px] font-semibold">
                    Executar <ExternalLink className="w-3 h-3" />
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </motion.div>
    </motion.div>
  );
};
